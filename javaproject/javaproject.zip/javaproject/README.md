# Overview

Learning how to make a GUI to be able to do a login in the future. 
This allows to have user input and then displays it back. 



The software that I wrote has a lot of setup for the GUI. Once setup you go into the specifics 
to get user-inputs and be able to display those inputs. You are also able to do a easy clear.
{Describe your purpose for writing this software.}
The purpose for this software was to learn some of the basics and advanced things in Java. It
will also help with the ability to be able to learn how to do a sign-in for future projects.

{Provide a link to your YouTube demonstration. It should be a 4-5 minute demo of the software running and a walkthrough of the code. Focus should be on sharing what you learned about the language syntax.}

[Software Demo Video](https://youtu.be/SKI1qsrkX14)

# Development Environment

{Describe the tools that you used to develop the software}

{Describe the programming language that you used and any libraries.}
I used Java for my projects and some of the libraries that I used 
in this project were:

- import java.awt.*;
- import java.awt.event.ActionEvent;
- import java.awt.event.ActionListener;
- import javax.swing.*;

These are just some of the libraries that were needed in order to get things to display
on the GUI.

# Useful Websites



- [W3Schools](https://www.w3schools.com/java/default.asp)


# Future Work

- Make it look nicer
- Add a json file to save the usernames and passwords to and then be able to read from it.

